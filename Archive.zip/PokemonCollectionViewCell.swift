//
//  PokemonCollectionViewCell.swift
//  PokedexLab
//
//  Created by Tom Kim on 3/2/17.
//  Copyright © 2017 iOS Decal. All rights reserved.
//

import UIKit

class PokemonCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
        
}
